package tech.akam.thefortyrulesoflove2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.appbar.MaterialToolbar;

import java.util.ArrayList;
import java.util.List;

import tech.akam.thefortyrulesoflove2.adapters.sumBookAdapter;
import tech.akam.thefortyrulesoflove2.app.app;
import tech.akam.thefortyrulesoflove2.objects.sumBookObjects;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    List<sumBookObjects> mItem = new ArrayList<> (  );
    sumBookAdapter sumBookAdapter;
    MaterialToolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_main );


    init();

    setData ();

    }

    private void init(){

        recyclerView   = findViewById ( R.id.recyclerView );
        toolbar        = findViewById ( R.id.toolbar );
        sumBookAdapter = new sumBookAdapter ( mItem , this );

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager ( getApplicationContext () );

//      RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager ( this , LinearLayoutManager.VERTICAL , false);
//      RecyclerView.LayoutManager gLayoutManager = new GridLayoutManager ( this , 2 );


        recyclerView.setLayoutManager ( mLayoutManager );
//      recyclerView.setLayoutManager ( gLayoutManager );

        RecyclerView.ItemDecoration itemDecoration = new DividerItemDecoration ( this , DividerItemDecoration.VERTICAL );
        recyclerView.addItemDecoration ( itemDecoration );

        recyclerView.setItemAnimator(new DefaultItemAnimator ());
        recyclerView.setHasFixedSize(true);

        recyclerView.setAdapter ( sumBookAdapter );
        toolbar.setTitle ( R.string.app_name_Fa );
        setSupportActionBar ( toolbar );

//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

//        toolbar.setTitle ( R.string.app_name_Fa );
//        toolbar.setTitleTextColor ( Color.WHITE );

//        getWindow ().getDecorView ().setLayoutDirection ( View.LAYOUT_DIRECTION_RTL );




    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater ().inflate ( R.menu.toolbar_menu , menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int menuItemsId = item.getItemId ();

        if (menuItemsId == R.id.settings){
            app.t (getString ( R.string.settings ) + " " + getString ( R.string.clicked ) );
        }
        else if ( menuItemsId == R.id.about) {
            app.t ( getString ( R.string.about ) + " " + getString ( R.string.about ) );
        }
        else if (menuItemsId == R.id.search){
            app.t ( getString ( R.string.search ) + " " + getString ( R.string.clicked ) );
        }
        else if ( menuItemsId == R.id.exit){
            finish ();
        }
       /* else if ( menuItemsId == android.R.id.home){
            onBackPressed ();
        }*/

        return super.onOptionsItemSelected ( item );
    }

    private void setData(){

        mItem.add ( new sumBookObjects ( getString ( R.string.introduction )) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law01 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law02 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law03 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law04 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law05 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law06 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law07 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law08 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law09 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law10 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law11 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law12 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law13 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law14 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law15 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law16 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law17 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law18 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law19 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law20 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law21 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law22 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law23 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law24 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law25 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law26 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law27 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law28 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law29 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law30 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law31 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law32 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law33 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law34 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law35 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law36 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law37 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law38 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law39 ) ) );
        mItem.add ( new sumBookObjects ( getString ( R.string.law40 ) ) );

        sumBookAdapter.notifyDataSetChanged ();

    }
}
