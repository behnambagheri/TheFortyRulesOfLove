package tech.akam.thefortyrulesoflove2.objects;

public class sumBookObjects {

    String rulesNumber;

    public sumBookObjects(String rulesNumber){

        this.rulesNumber = rulesNumber;

    }

    public void setRulesNumber(String rulesNumber){
        this.rulesNumber = rulesNumber;
    }
    public String getRulesNumber(){
        return this.rulesNumber;
    }

}
