package tech.akam.thefortyrulesoflove2.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import tech.akam.thefortyrulesoflove2.R;
import tech.akam.thefortyrulesoflove2.app.app;
import tech.akam.thefortyrulesoflove2.objects.sumBookObjects;

public class sumBookAdapter extends RecyclerView.Adapter<sumBookAdapter.myViewHolder>{

    private List<sumBookObjects> objectsList;
    private Context myContext;


    public sumBookAdapter(List<sumBookObjects> objectsList , Context myContext){
        this.objectsList = objectsList;
        this.myContext = myContext;
    }


    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from ( parent.getContext () ).inflate ( R.layout.list_item , parent , false);
        return new myViewHolder ( view );
    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder holder, final int position) {

        final sumBookObjects objects = objectsList.get ( position );

        holder.rulesNumber.setText ( objects.getRulesNumber () );

        holder.linearLayout.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick(View v) {
//                Toast.makeText ( myContext, "ITEM " + position + " Clicked" , Toast.LENGTH_SHORT).show ();
                app.t (objectsList.get ( position ).getRulesNumber ());
            }
        } );

    }

    @Override
    public int getItemCount() {
        return objectsList.size ();
    }

    class myViewHolder extends RecyclerView.ViewHolder {

        private TextView rulesNumber;
        private LinearLayout linearLayout;

        private myViewHolder(@NonNull View itemView) {
            super ( itemView );

            rulesNumber = itemView.findViewById ( R.id.rulesNumber );
            linearLayout = itemView.findViewById ( R.id.linearLayout );
        }
    }
}
